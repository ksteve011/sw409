package com.sw409.Patient.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sw409.Patient.models.Patient;
import com.sw409.Patient.repositories.PatientRepository;

@Service
public class PatientService {
	
	@Autowired
	PatientRepository patientRepository;

    List <Patient> patientList = new ArrayList<>();
	//create list of patients

	public Patient createPatient(Patient patient){
		patientList.add(patient);
		return patientRepository.save(patient);
	}

	//read list of patients

	public List<Patient> findAllPatients(){
		return (List<Patient>) patientRepository.findAll();
	}

	//update a patient by id
	public void updatePatient(int id, Patient patient){
		Patient oldpt = patientRepository.findById(id).get();
	    oldpt.setPtage(patient.getPtage());
	    oldpt.setPtname(patient.getPtname());
	    patientRepository.save(patient);
		}
	
	//find patient by id
	public Patient findPatientByIllness(int id, Patient patient)
	{
		return patientRepository.findById(id).get();
	}
	//delete patient by id
	public void deletePatient(Integer id){
		patientRepository.deleteById(id);
	}


}
