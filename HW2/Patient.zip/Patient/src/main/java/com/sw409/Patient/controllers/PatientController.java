package com.sw409.Patient.controllers;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;

import com.sw409.Patient.models.Patient;
import com.sw409.Patient.services.PatientService;

import java.util.List;

@RestController
public class PatientController {

	@Autowired
	PatientService patientService;
	
	@PostMapping("api/v1/patients")
	public Patient createPatient(@RequestBody Patient patient){

		return patientService.createPatient(patient);

	}

	@GetMapping("api/v1/patients")
	public List<Patient> findAllPatients(){
		return patientService.findAllPatients();
	}


	@PutMapping("api/v1/patients/{patientId}")
	public void updatePatient(@PathVariable("patientid") Integer id, @RequestBody Patient patient){
		patientService.updatePatient(id, patient);

	}


	@DeleteMapping("api/v1/patients/{patientId}")
	public void deletePatient(@PathVariable("patientid") Integer id){
		patientService.deletePatient(id);
	}
}
	/*
	@GetMapping("api/v1/patients/{illness}")
	public List<Patient> findPatientsByIllness(@PathVariable("illness") String illness){


	}
	*/
