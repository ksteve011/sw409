package com.sw409.Patient.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Patient {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	String ptname;
	int ptid;
	String ptdisease;
	int ptage; 
	String ptdoctor;
	
	public Patient() {
		
	}

	public String getPtname() {
		return ptname;
	}

	public void setPtname(String ptname) {
		this.ptname = ptname;
	}

	public int getPtid() {
		return ptid;
	}

	public void setPtid(int ptid) {
		this.ptid = ptid;
	}

	public String getPtdisease() {
		return ptdisease;
	}

	public void setPtdisease(String ptdisease) {
		this.ptdisease = ptdisease;
	}

	public int getPtage() {
		return ptage;
	}

	public void setPtage(int ptage) {
		this.ptage = ptage;
	}

	public String getPtdoctor() {
		return ptdoctor;
	}

	public void setPtdoctor(String ptdoctor) {
		this.ptdoctor = ptdoctor;
	}
}